Prism.languages['t4-vb'] = Prism.languages['t4-templating'].createT4('vbnet');
